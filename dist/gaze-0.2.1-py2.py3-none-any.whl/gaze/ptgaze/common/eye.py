from gaze.ptgaze.common.face_parts import FaceParts


class Eye(FaceParts):
    pass
